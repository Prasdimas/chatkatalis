import { DataTypes } from 'sequelize';
import db from "../config/Database.js";
import Users from './UserModel.js';

const UserClick = db.define('UserClick', {
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  user_token: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  click_count: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
});


UserClick.belongsTo(Users, { foreignKey: 'id' });

export default UserClick;
