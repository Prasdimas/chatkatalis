import express from 'express';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import db from './config/Database.js';
import router from './routes/index.js';
import { Configuration, OpenAIApi } from 'openai';
import UserClick from './models/UserClick.js';

dotenv.config();

const app = express();
app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

const startServer = async () => {
  try {
    await db.authenticate();
    console.log('Database Connected...');
  } catch (error) {
    console.error(error);
  }

  app.use(cors({
    credentials: true,
    origin: ['http://localhost:3000']
  }));
  app.use(cookieParser());
  app.use(express.json());
  app.use(router);

  const openaiApiKey = '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';

  app.get('/api/openai-key', (req, res) => {
    res.json({ openaiApiKey });
  });

  app.post('/api/openai-request', async (req, res) => {
    const { option, input } = req.body;

    const configuration = new Configuration({
      apiKey: openaiApiKey,
    });

    const openai = new OpenAIApi(configuration);

    try {
      const response = await openai.createCompletion({ ...option, prompt: input });
      const result = response.data.choices[0].text;

      res.json({ result });
    } catch (error) {
      console.error('Kesalahan saat melakukan permintaan OpenAI:', error);
      res.status(500).json({ error: 'Terjadi kesalahan saat melakukan permintaan OpenAI.' });
    }
  });

  app.listen(5000, () => console.log('Server running at port 5000'));
};

startServer();
